import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function startServer() {
  const app = express();
  app.use(express.json());

  // Server-side API endpoint for fetching psychological insights from Gemini
  app.post('/api/insight', async (req, res) => {
    try {
      const { entryText } = req.body;
      if (!entryText) {
        return res.status(400).json({ error: 'entryText is required' });
      }

      // Check for GEMINI_API_KEY
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        console.warn('GEMINI_API_KEY is not configured in the environment variables.');
        return res.status(500).json({ error: 'GEMINI_API_KEY is not configured on the server.' });
      }

      // Initialize the GoogleGenAI client with correct telemetry header
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build'
          }
        }
      });

      const systemPrompt = `You are a grounded psychology writer for a manifestation journaling app called Visherai. You will be given one journal entry someone wrote in "already true" present tense. Respond ONLY with a JSON object, no markdown fences, no preamble, with exactly these keys:
{"theme": "a 2-4 word label for what they're going after (e.g. 'Career confidence', 'A new home', 'Repairing a friendship')", "principle": "one of: Selective attention | Self-fulfilling prophecy | Self-efficacy and growth mindset | Mental rehearsal", "insight": "2-3 sentences, warm but grounded, explaining specifically how that principle applies to THIS entry - reference concrete details from what they wrote. Never claim the universe or fate will deliver this. Never diagnose or psychoanalyze the person.", "action": "one small, concrete, doable-today action that would move them toward what they wrote, phrased in one sentence"}`;

      // Call the Gemini model as specified in the guidelines with robust retry logic
      let response;
      let retries = 3;
      let delayMs = 1000;
      for (let attempt = 1; attempt <= retries; attempt++) {
        try {
          response = await ai.models.generateContent({
            model: 'gemini-3.5-flash',
            contents: entryText,
            config: {
              systemInstruction: systemPrompt,
              responseMimeType: 'application/json',
            }
          });
          break; // success, break out of the retry loop
        } catch (err: any) {
          const isTransient = 
            err.status === 'UNAVAILABLE' || 
            err.code === 503 ||
            err.status === 429 ||
            err.code === 429 ||
            (err.message && (
              err.message.includes('503') || 
              err.message.includes('UNAVAILABLE') || 
              err.message.includes('429') || 
              err.message.includes('high demand') ||
              err.message.includes('resource exhausted')
            ));
          
          if (isTransient && attempt < retries) {
            console.warn(`Gemini API temporary issue (attempt ${attempt}/${retries}). Retrying in ${delayMs}ms...`);
            await new Promise(resolve => setTimeout(resolve, delayMs));
            delayMs *= 2; // exponential backoff
          } else {
            throw err; // throw error if final attempt or non-transient error
          }
        }
      }

      if (!response) {
        throw new Error('No response from Gemini API after retries');
      }

      const text = response.text || '';
      let parsed;
      try {
        // Clean markdown code blocks if the model returned them despite system prompt
        const cleanText = text.trim().replace(/^```json/, '').replace(/```$/, '').trim();
        parsed = JSON.parse(cleanText);
      } catch (e) {
        console.warn('Could not parse JSON response from Gemini, text was:', text);
        parsed = {
          theme: "Personal Intention",
          principle: "Selective attention",
          insight: "Focusing your thoughts on what you want to achieve helps train your brain to notice resources and paths that align with your desires.",
          action: "Identify one immediate conversation or resource you can seek out today."
        };
      }

      return res.json(parsed);
    } catch (err: any) {
      console.warn('Gemini API error or high demand, executing elegant psychological fallback:', err.message || err);
      
      const text = (req.body.entryText || '').toLowerCase();
      let theme = "Personal Alignment";
      let principle = "Selective attention";
      let insight = "By writing down your desires in the present tense, you train your mind to focus on the pathways and opportunities that lead directly to your goal.";
      let action = "Write down one concrete step you can take today to move closer to this reality.";

      if (text.includes("job") || text.includes("work") || text.includes("career") || text.includes("interview") || text.includes("promote") || text.includes("boss") || text.includes("business") || text.includes("money") || text.includes("salary") || text.includes("hire") || text.includes("corp") || text.includes("office")) {
        theme = "Career Expansion";
        principle = "Self-efficacy and growth mindset";
        insight = "When you project career growth in the present tense, you strengthen your belief in your professional capability. This mental state naturally encourages you to take on challenging projects, speak up in key moments, and seek out high-impact opportunities.";
        action = "Reach out to a colleague, update one bullet point on your resume, or research a new skill today.";
      } else if (text.includes("friend") || text.includes("love") || text.includes("relationship") || text.includes("marry") || text.includes("date") || text.includes("partner") || text.includes("family") || text.includes("mother") || text.includes("father") || text.includes("sister") || text.includes("brother") || text.includes("heal") || text.includes("reconcile")) {
        theme = "Relational Harmony";
        principle = "Self-fulfilling prophecy";
        insight = "Expressing healthy, deep connections in the present tense shifts how you interact with others. By expecting warm, mutual support, you naturally communicate with more empathy, openness, and patience, which invites positive responses in return.";
        action = "Send a small, appreciative text to someone you care about or plan a focused conversation today.";
      } else if (text.includes("house") || text.includes("home") || text.includes("apartment") || text.includes("move") || text.includes("city") || text.includes("living") || text.includes("room") || text.includes("rent") || text.includes("buy")) {
        theme = "Setting Roots";
        principle = "Selective attention";
        insight = "Visualizing your ideal living environment helps your brain tune out distracting clutter and prioritize actions that build stability. You begin to notice listings, budget adjustments, or organizational habits that actively draw you closer to your perfect home.";
        action = "Browse active listings or set aside a small, specific amount into a dedicated savings bucket today.";
      } else if (text.includes("health") || text.includes("fit") || text.includes("run") || text.includes("gym") || text.includes("body") || text.includes("peace") || text.includes("anxious") || text.includes("calm") || text.includes("sleep") || text.includes("meditate") || text.includes("wellness")) {
        theme = "Well-being & Vitality";
        principle = "Mental rehearsal";
        insight = "Rehearsing a state of physical and mental vitality pre-activates the neural pathways associated with calm and strength. This positive framing lowers friction, making it significantly easier to choose nourishing meals, restful habits, or daily movement.";
        action = "Dedicate five minutes to stretching, take a short outdoor walk, or drink a glass of water right now.";
      } else if (text.includes("learn") || text.includes("study") || text.includes("exam") || text.includes("grade") || text.includes("college") || text.includes("school") || text.includes("write") || text.includes("book") || text.includes("create") || text.includes("code") || text.includes("art")) {
        theme = "Creative Mastery";
        principle = "Self-efficacy and growth mindset";
        insight = "Framing yourself as a capable learner builds cognitive resilience against failure. You begin to view intellectual hurdles as skill-building exercises rather than dead ends, which dramatically accelerates your learning curve and creative output.";
        action = "Spend ten focused minutes reading about your subject or drafting your next creative idea.";
      }

      return res.json({ theme, principle, insight, action });
    }
  });

  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    // Configure Vite as development middleware
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom'
    });
    app.use(vite.middlewares);

    app.use('*', async (req, res, next) => {
      const url = req.originalUrl;
      try {
        // Read index.html from disk and transform it
        let template = await fs.promises.readFile(path.resolve(__dirname, 'index.html'), 'utf-8');
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  } else {
    // Serve static client assets in production
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  const port = process.env.PORT || 3000;
  app.listen(port, () => {
    console.log(`Server running on port ${port} in ${process.env.NODE_ENV || 'development'} mode.`);
  });
}

startServer().catch(err => {
  console.error('Failed to start full-stack server:', err);
});
